$("textarea").keyup(function() {
    if (this.value.length > 200)
        this.value = this.value.substr(0, 200);
});