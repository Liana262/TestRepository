namespace MusicProject.Enums
{
    public enum Role
    {
        Guest = 0,
        User = 1,
        Artist = 2
    }
}