using System.ComponentModel.DataAnnotations;
using MusicProject.Enums;

namespace MusicProject.Model
{
    public class User
    {
        [Required]
        public int Id { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        [RegularExpression(@"^[A-Za-z]+$", ErrorMessage = "Никнейм должно содержать только латинские буквы")]
        [MaxLength (15)]
        public string Username { get; set; }
        [Required]
        public bool IsMember { get; set; }
        public string ImagePath { get; set; }
        public Role Role { get; set; }
        
        public string Key { get; set; }
        
    }
}