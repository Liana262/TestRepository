using MusicProject.Enums;

namespace MusicProject.Model
{
    public class Artist
    {
        public int Id { get; set; }
        
        public string ArtistName { get; set; }
        
        public string Tracks { get; set; }

        public Role Role = Role.Artist;
        
        public string ImagePath { get; set; }
    }
}