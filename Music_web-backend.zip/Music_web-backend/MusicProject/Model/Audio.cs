namespace MusicProject.Model
{
    public class Audio
    {
        public int Id { get; set; }
        
        public string ArtistName { get; set; }
        
        public string SongName { get; set; }
        
        public string Genre { get; set; }
        
        public string AudioPath { get; set; }
    }
}