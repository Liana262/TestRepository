namespace MusicProject.Model
{
    public class Message
    {
        public int Id { get; set; }
        
        public string TextMessage { get; set; }
        
        public int UserId { get; set; }
        
        public int ChatId { get; set; }
    }
}