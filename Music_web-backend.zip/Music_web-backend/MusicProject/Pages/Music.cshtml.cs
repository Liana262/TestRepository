using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.DependencyInjection;
using MusicProject.Model;
using MusicProject.Repository;

namespace MusicProject.Pages
{
    public class Music : PageModel
    {
        public List<Audio> Audios { get; set; }
        
        public User User { get; set; }
        public List<Artist> Artists { get; set; }
        
        [BindProperty]
        public string Genre { get; set; }
        
        public async Task OnGet()
        {
            var audioRepository = HttpContext.RequestServices.GetService<IAudioRepository>();
            var artistRepository = HttpContext.RequestServices.GetService<IArtistRepository>();
            var userRepository = HttpContext.RequestServices.GetService<IUserRepository>();

            Artists = await artistRepository.GetArtists();
            
            if (HttpContext.Request.Query.ContainsKey("focus"))
            {
                var search = (string) HttpContext.Request.Query["focus"];
                Audios = await audioRepository.GetAudioByInput(search);
            }
            else
            {
                Audios = await audioRepository.GetAudio();
            }
            
            if ( Genre != null)
            {
                Audios = await audioRepository.GetAudioByGenre(Genre);
            }

            if (Genre == "Choose genre")
            {
                Audios = await audioRepository.GetAudio();
            }
            
        }

        public async Task<User> GetUsername(string username)
        {
            foreach (var artist in Artists)
            {
                if (username == artist.ArtistName)
                {
                    var usernameArt = artist.ArtistName;
                    var userRepository = HttpContext.RequestServices.GetService<IUserRepository>();
                    var user = await userRepository.GetUserByName(usernameArt);
                    return user;
                }
            }
            return null;
        }
       
        public async Task OnPost()
        {
            await OnGet();
        }
        
    }
}