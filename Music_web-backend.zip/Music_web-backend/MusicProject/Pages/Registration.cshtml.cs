using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MusicProject.Model;

namespace MusicProject.Pages
{
    public class Registration : PageModel
    {
        
        public void OnGet()
        {
            
        }
    }
}