using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MusicProject.Pages
{
    public class FAQ : PageModel
    {
        public void OnGet()
        {
            
        }
    }
}