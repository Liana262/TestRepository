using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.DependencyInjection;
using MusicProject.Model;
using MusicProject.Repository;

namespace MusicProject.Pages
{
    public class Community : PageModel
    {
        public List<User> Users { get; set; }
        public async Task OnGet()
        {
            var userRepository = HttpContext.RequestServices.GetService<IUserRepository>();
            Users = await userRepository.GetUsers();
        }
    }
}