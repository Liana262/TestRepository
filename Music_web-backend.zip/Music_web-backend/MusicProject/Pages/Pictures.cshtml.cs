using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.DependencyInjection;
using MusicProject.Model;
using MusicProject.Repository;

namespace MusicProject.Pages
{
    public class Pictures : PageModel
    {
        public List<User> Users { get; set; }
        
        public int[] RandomUsers { get; set; }
        public async Task OnGet()
        {
            var userRepository = HttpContext.RequestServices.GetService<IUserRepository>();
            Users = await userRepository.GetUsers();
            int[] randomInt = new int[3];
            var random = new Random();
            for (int count = 0; count < 3; count++) 
            {
                randomInt[count] = random.Next(1,Users.Count);
                
            }
            RandomUsers = randomInt;
        }
    }
}