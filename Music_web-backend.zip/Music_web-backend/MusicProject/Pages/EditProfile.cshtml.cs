using System;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.DependencyInjection;
using MusicProject.Enums;
using MusicProject.Helpers;
using MusicProject.Model;
using MusicProject.Repository;

namespace MusicProject.Pages
{
    public class EditProfile : PageModel
    {
        [BindProperty] 
        [MaxLength(10)]
        [RegularExpression(@"^[A-Za-z]+$", ErrorMessage = "Никнейм должен содержать только латинские буквы")]
        public string NewUsername { get; set; }
        
        
        private IWebHostEnvironment _appEnvironment;
        [BindProperty]
        public IFormFile ProfilePic { get; set; }
        
        public EditProfile(IWebHostEnvironment appEnvironment)
        {
            _appEnvironment = appEnvironment;
        }
        
        [BindProperty]
        public bool NewIsMember { get; set; }
        
        [BindProperty]
        public string IsMemberString { get; set; }
        
        [BindProperty]
        [MaxLength(20)]
        [MinLength(8, ErrorMessage = "Пароль должен содержать не менее 8 символов")]
        public string OldPassword { get; set; }
        [BindProperty]
        [MaxLength(20)]
        [MinLength(8,ErrorMessage = "Пароль должен содержать не менее 8 символов")]
        public string NewPassword { get; set; }
        [BindProperty]
        [MaxLength(20)]
        [MinLength(8,ErrorMessage = "Пароль должен содержать не менее 8 символов")]
        [Compare(nameof(NewPassword), ErrorMessage = "Пароли не совпадают")]
        public string ConfirmPassword { get; set; }
        
        private bool GetIsMember(string input)
        {
            switch (input)
            {
              case  "Yes":
                  return true;
              case "No":
                  return false;
              default:
                  throw new Exception();
            }
        }

        public async Task<IActionResult> OnPost()
        {
            var user = HttpContext.Session.Get<User>("user");
            var userRepository = HttpContext.RequestServices.GetService<IUserRepository>();

            if (NewUsername != null)
            {
                await userRepository.UpdateUserUsername(user.Id, NewUsername);
            }

            if (IsMemberString != null)
            {
                var isMember = GetIsMember(IsMemberString);
                await userRepository.UpdateIsMember(user.Id, isMember);
            }

            if (ProfilePic != null)
            {
                var imagePath = await AddAvatar();
                await userRepository.UpdateProfilePic(user.Id, imagePath);
            }

            if (await userRepository.IsPasswordMatch(user.Id, OldPassword) && ConfirmPassword == NewPassword)
            {
                await userRepository.UpdateUserPassword(user.Id, NewPassword);
            }
           
            var newUser = await userRepository.GetUserById(user.Id);
            HttpContext.Session.Set("user", newUser);
            return Redirect("/MyProfile?id="+user.Id);
        }
        
        private async Task<string> AddAvatar()
        {
            if (ProfilePic != null)
            {
                string path = "/images/" + ProfilePic.FileName;
                using (var fileStream = new FileStream(_appEnvironment.WebRootPath + path, FileMode.Create))
                {
                    await ProfilePic.CopyToAsync(fileStream);
                }

                return path;
            }
            return null;
        }
        
    }
}