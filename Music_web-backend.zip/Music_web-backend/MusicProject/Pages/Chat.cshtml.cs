using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.DependencyInjection;
using MusicProject.Helpers;
using MusicProject.Model;
using MusicProject.Repository;

namespace MusicProject.Pages
{
    public class Chat : PageModel
    {
        [BindProperty]
        [MaxLength (200)]
        public string TextMessage { get; set; }

        public List<Message> Messages { get; set; }
        
        public int ChatId { get; set; }
        
        public Model.Chat Chats { get; set; }
        
        public async Task OnGet()
        {
            ChatId = Convert.ToInt32(HttpContext.Request.Query["id"]);
            var repository = HttpContext.RequestServices.GetService<IMessageRepository>();
            Messages = await repository.GetChatMessages(ChatId);
            var chatRep = HttpContext.RequestServices.GetService<IChatRepository>();
            Chats = await chatRep.GetChatById(ChatId);

        }

        public async Task<IActionResult> OnPost()
        {
            var chatId = Convert.ToInt32(HttpContext.Request.Form["chatId"]);
            var user = HttpContext.Session.Get<User>("user");
            var messageRepository = HttpContext.RequestServices.GetService<IMessageRepository>();
            
            if (TextMessage != null)
            {
                await messageRepository.AddMessage(user.Id, TextMessage, chatId);
            }

            return Redirect($"/Chat?id={chatId}");
        }
        
    }

    public class Chats
    {
    }
}