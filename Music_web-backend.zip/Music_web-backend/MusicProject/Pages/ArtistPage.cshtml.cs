using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.DependencyInjection;
using MusicProject.Model;
using MusicProject.Repository;

namespace MusicProject.Pages
{
    public class ArtistPage : PageModel
    {
        public Artist Artist { get; set; }
        
        public List<Audio> Audios { get; set; }
        
        public async Task OnGet()
        {

            if (HttpContext.Request.Query.ContainsKey("id"))
            {
                var userId = Convert.ToInt32(HttpContext.Request.Query["id"]);
                var artistRepository = HttpContext.RequestServices.GetService<IArtistRepository>();
                Artist = await artistRepository.GetArtistById(userId);
                var audioRep = HttpContext.RequestServices.GetService<IAudioRepository>();
                Audios =await audioRep.GetAudioByArtist(Artist.ArtistName);
            }
            
            
        }
    }
}