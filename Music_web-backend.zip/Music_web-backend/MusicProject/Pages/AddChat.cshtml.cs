using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.DependencyInjection;
using MusicProject.Repository;

namespace MusicProject.Pages
{
    public class AddChat : PageModel
    {
        [BindProperty]
        [MaxLength(20, ErrorMessage = "Chat name should be 20")]
        public string ChatName { get; set; }
        
        public void OnGet()
        {
            
        }

        public async Task<IActionResult> OnPost()
        {
            var chatRepository = HttpContext.RequestServices.GetService<IChatRepository>();
            if (ChatName != null)
            {
                await chatRepository.AddChat(ChatName);
            }
            return Redirect("Index");
        }
    }
}