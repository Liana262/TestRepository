using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.DependencyInjection;
using MusicProject.Helpers;
using MusicProject.Model;
using MusicProject.Repository;

namespace MusicProject.Pages
{
    public class MyProfile : PageModel
    {
        public User User { get; set; }
        
        
        public async Task OnGet()
        {
            if (HttpContext.Request.Query.ContainsKey("id"))
            {
                var currentUserId = Convert.ToInt32(HttpContext.Request.Query["id"]);
                var userRepository = HttpContext.RequestServices.GetService<IUserRepository>();
                User = await userRepository.GetUserById(currentUserId);
            }
        }
    }
}