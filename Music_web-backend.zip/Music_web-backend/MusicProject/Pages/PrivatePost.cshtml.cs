using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.DependencyInjection;
using MusicProject.Enums;
using MusicProject.Helpers;
using MusicProject.Model;
using MusicProject.Repository;

namespace MusicProject.Pages
{
    public class PrivatePost : PageModel
    {
        public void OnGet()
        {

        }

        public async Task<IActionResult> OnPostSignIn()
        {
            var email = (string)HttpContext.Request.Form["email_signin"];
            var password = (string) HttpContext.Request.Form["password_signin"];
            var repository = HttpContext.RequestServices.GetService<IUserRepository>();
            var shouldRemember = (string) HttpContext.Request.Form["rememberMe"];

            var user = await repository.GetUser(email, password);
            
            if (user.Role == Role.Guest)
            {
                return Redirect("Registration");
            }

            if (shouldRemember == "on")
            {
                SetCookie(user.Key);
            }

            HttpContext.Session.SetString("role", user.Role.ToString());
            HttpContext.Session.Set("user", user);
            return Redirect("/Index");
            
        }
        
        private void SetCookie(string enterKey)
        {
            HttpContext.Response.Cookies.Append("enterkey", enterKey);
        }
        
        public IActionResult OnGetLogOut()
        {
            HttpContext.Session.Remove("user");
            HttpContext.Session.SetString("role", Role.Guest.ToString());
            HttpContext.Response.Cookies.Delete("enterkey");
            return Redirect("/Index");
        }
        public async Task<IActionResult> OnPostSignUp()
        {
            var username = (string)HttpContext.Request.Form["username_signup"];
            var password = (string)HttpContext.Request.Form["password_signup"];
            var passwordConfirm = (string)HttpContext.Request.Form["password_confirm"];
            var email = (string)HttpContext.Request.Form["email"];
            
            if (password == passwordConfirm)
            {
                var repository = HttpContext.RequestServices.GetService<IUserRepository>();
                var user = new User();
                user.Username = username;
                user.Email = email;
                user.Role = Role.User;
                await repository.AddUser(user, password);
                return Redirect("/Index");
            }
            else
            {
                return Redirect("/Index");
            }
        }
    }
}