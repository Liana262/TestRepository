using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MusicProject.Model;
using Dapper;
using Microsoft.Extensions.Configuration.UserSecrets;
using Npgsql;




namespace MusicProject.Repository
{
    public class MessageRepository : IMessageRepository
    {
        private string connectionString = 
            "User ID=postgres;Password=postgres;Host=localhost;Port=5432;Database=music";


        public async Task AddMessage(int userId, string message, int chatId)
        {
            await using (var connection = new NpgsqlConnection(connectionString))
            {
                await connection.OpenAsync();
                connection.Execute(
                    "INSERT INTO message (user_id, text_message, chat_id) VALUES (@UserId, @Message, @ChatId)",
                    new {UserId = userId, Message = message, ChatId = chatId});
            }
        }

        public async Task<List<Message>> GetChatMessages(int chatId)
        {
            await using (var connection = new NpgsqlConnection(connectionString))
            {
                await connection.OpenAsync();
                var messagesList = connection.Query<Message>("select id, user_id as UserId, text_message as TextMessage, chat_id as ChatId from message where chat_id = @ChatId",
                    new {ChatId = chatId}).ToList();
                return messagesList;
            }
           
        }
    }
}