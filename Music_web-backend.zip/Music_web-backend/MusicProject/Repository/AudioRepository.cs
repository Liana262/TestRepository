using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using MusicProject.Model;
using Npgsql;

namespace MusicProject.Repository
{
    public class AudioRepository : IAudioRepository
    {
        private string connectionString = 
            "User ID=postgres;Password=postgres;Host=localhost;Port=5432;Database=music";
        
        public async Task<List<Audio>> GetAudio()
        {
            await using (var connection = new NpgsqlConnection(connectionString))
            {
                await connection.OpenAsync();
                var audioList = connection.Query<Audio>(
                    "select id, artist_name as ArtistName, song_name as SongName, genre, audio_path as AudioPath from audio").ToList();
                return audioList;
            }
        }

        public async Task<List<Audio>> GetAudioByGenre(string genre)
        {
            await using (var connection = new NpgsqlConnection(connectionString))
            {
                await connection.OpenAsync();
                var audioList =
                    connection.Query<Audio>(
                        "select id, artist_name as ArtistName, song_name as SongName, genre, audio_path as AudioPath from audio where genre = @Genre",
                        new {Genre = genre}).ToList();
                return audioList;
            }
        }

        public async Task<List<Audio>> GetAudioByInput(string input)
        {
            var sql =
                @"select id, artist_name as ArtistName, song_name as SongName, genre, audio_path as AudioPath from audio where lower(song_name) like lower(@Input)";
            using (var connection = new NpgsqlConnection(connectionString))
            {
                await connection.OpenAsync();
                var result
                    = connection.Query<Audio>(sql, new {Input = "%" + input + "%"}).ToList();
                return result;
            }
        }

        public async Task<List<Audio>> GetAudioByArtist(string artist)
        {
            var sql =
                @"select id, artist_name as ArtistName, song_name as SongName, genre, audio_path as AudioPath from audio where artist_name = @ArtistName";
            using (var connection = new NpgsqlConnection(connectionString))
            {
                await connection.OpenAsync();
                var result = connection.Query<Audio>(sql, new {@ArtistName = artist}).ToList();
                return result;
            }
        }
    }
}