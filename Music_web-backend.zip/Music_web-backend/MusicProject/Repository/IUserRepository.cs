using System.Collections.Generic;
using System.Threading.Tasks;
using MusicProject.Model;

namespace MusicProject.Repository
{
    public interface IUserRepository
    {
        Task AddUser(User user, string password);

        Task<User> GetUser(string email, string password);

        Task UpdateUserUsername(int userId, string newUsername);

        Task UpdateIsMember(int userId, bool isMember);

        Task<User> GetUserById(int id);

        Task UpdateUserPassword(int userId, string newPassword);

        Task UpdateProfilePic(int userId, string imagePath);
        Task<bool> IsPasswordMatch(int userId, string password);

        Task<List<User>> GetUsers();

        Task<User> GetUserByEnterKey(string enterKey);

        Task<User> GetUserByName(string username);
    }
}