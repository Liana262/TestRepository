using System.Collections.Generic;
using System.Threading.Tasks;
using MusicProject.Model;

namespace MusicProject.Repository
{
    public interface IMessageRepository
    {
        Task AddMessage(int userId, string message, int chatId);

        Task<List<Message>> GetChatMessages(int chatId);
    }
}