using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using MusicProject.Model;
using Npgsql;

namespace MusicProject.Repository
{
    public class ChatRepository: IChatRepository
    {
        private string connectionString = 
            "User ID=postgres;Password=postgres;Host=localhost;Port=5432;Database=music";
        
        public async Task<List<Chat>> GetChats()
        {
            await using (var connection = new NpgsqlConnection(connectionString))
            {
                await connection.OpenAsync();
                var chatsList = connection.Query<Chat>("select id, chat_name as ChatName from chats").ToList();
                return chatsList;
            }
        }

        public async Task<Chat> GetChatById(int id)
        {
            using (var connection = new NpgsqlConnection(connectionString))
            {
                await connection.OpenAsync();
                var chat = connection.QueryFirstOrDefault<Chat>(@"select id, chat_name as ChatName from chats where id = @Id",
                    new {Id = id});
                return chat;
            }
        }

        public async Task AddChat(string chatname)
        {
            using (var connection = new NpgsqlConnection(connectionString))
            {
                await connection.OpenAsync();
                connection.Execute(@"insert into chats (chat_name) values (@ChatName)",
                    new {ChatName = chatname});
            }
        }
    }
}