using System.Collections.Generic;
using System.Threading.Tasks;
using MusicProject.Model;

namespace MusicProject.Repository
{
    public interface IAudioRepository
    {
        Task<List<Audio>> GetAudio();

        Task<List<Audio>> GetAudioByGenre(string genre);

        Task<List<Audio>> GetAudioByInput(string input);

        Task<List<Audio>> GetAudioByArtist(string artist);
    }
}