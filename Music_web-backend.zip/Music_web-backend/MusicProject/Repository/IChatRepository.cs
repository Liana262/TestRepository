using System.Collections.Generic;
using System.Threading.Tasks;
using MusicProject.Model;

namespace MusicProject.Repository
{
    public interface IChatRepository
    {
        Task<List<Chat>> GetChats();

        Task<Chat> GetChatById(int id);
        Task AddChat(string chatname);
    }
}