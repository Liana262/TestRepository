using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using MusicProject.Model;
using Npgsql;

namespace MusicProject.Repository
{
    public class ArtistRepository : IArtistRepository
    {
        private string connectionString = 
            "User ID=postgres;Password=postgres;Host=localhost;Port=5432;Database=music";
        
        public async Task<Artist> GetArtistByName(string name)
        { 
            using (var connection = new NpgsqlConnection(connectionString))
            {
                await connection.OpenAsync();
                var artist = connection.QueryFirstOrDefault<Artist>(
                    @"select id, artist_name as ArtistName, tracks as Tracks, role as Role, imagepath as ImagePath from artist where artist_name = @ArtistName",
                    new {ArtistName = name});
                return artist;
            }
        }

        public async Task<List<Artist>> GetArtists()
        {
            using (var connection = new NpgsqlConnection(connectionString))
            {
                await connection.OpenAsync();
                var artists = connection
                    .Query<Artist>(@"select id, artist_name as ArtistName, tracks as Tracks, role as Role, imagepath as ImagePath from artist")
                    .ToList();
                return artists;
            }
        }

        public async Task<Artist> GetArtistById(int id)
        {
            using (var conection = new NpgsqlConnection(connectionString))
            {
                await conection.OpenAsync();
                var artist = conection.QueryFirstOrDefault<Artist>(
                    @"select id, artist_name as ArtistName, tracks as Tracks, role as Role, imagepath as ImagePath from artist where id = @Id",
                    new {Id = id});
                return artist;
            }
        }
    }
}