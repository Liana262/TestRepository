using System.Collections.Generic;
using System.Threading.Tasks;
using MusicProject.Model;

namespace MusicProject.Repository
{
    public interface IArtistRepository
    {
        Task<Artist> GetArtistByName(string name);

        Task<Artist> GetArtistById(int id);

        Task<List<Artist>> GetArtists();
    }
}